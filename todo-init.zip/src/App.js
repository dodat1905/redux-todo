import React, { Component } from 'react';
import './App.css';
import MainTodo from './pages/main_todo/main_todo'

class App extends Component {

  render() {
    return (
      <MainTodo />
    );
  }
}

export default App;
